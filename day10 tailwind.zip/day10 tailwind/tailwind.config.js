/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/**/*.{html,js}"],
  theme: {
    colors: {
      black : 'var(--black)',
      white: 'var(--white)',
      orange: 'var(--orange)',
      gray: 'var(--gray)',
      blue: 'var(--blue)',
      red: 'var(--red)',
    },
    fontFamily: {
      'Dancing-Script': 'var(--font-Dancing-Script)',
      'Lato': 'var(--font-Lato)',
      'Poppins': 'var(--font-Poppins)',
    },
    container: {
        center: true,
    },
    extend: {
      height:{
        'aside': 'calc(100vh - 64px)',
      }
    },
  },
  plugins: [],
}

